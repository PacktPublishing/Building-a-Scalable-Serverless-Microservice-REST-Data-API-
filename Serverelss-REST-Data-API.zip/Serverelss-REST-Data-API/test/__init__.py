import sys
sys.path.append("../")

import lambda_dynamo_get
from lambda_dynamo_get import *
